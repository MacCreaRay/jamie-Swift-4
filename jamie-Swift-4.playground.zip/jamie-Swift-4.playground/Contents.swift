import UIKit

/*
                Assignment 4: Swift Protocols and Classes (Monster Edition)
                Due Date: Monday Dec 9, 2024 before class begins.
                Repo Name: firstName-Swift-4 (neo-Swift-4)

 **Objective**
    - Create a base protocol with common properties or methods for monsters.
    - Derive two child protocols for specific monster types.
    - Create four classes (two flying and two water monsters) conforming to these child protocols.
    - Write a function that accepts a collection of `Monster` objects and prints details about each.

**Instructions**
    Step 1: Define the Base Protocol
    - `Monster` with:
    - `var name: String { get }`
    - `func roar() -> String`

    Step 2: Define Child Protocols
    - `FlyingMonster` with:
    - `var wingSpan: Double { get }`
    - `func fly() -> String`
    - `WaterMonster` with:
    - `var swimSpeed: Int { get }`
    - `func swim() -> String`

    Step 3: Create Four Classes
    - `Dragon` and `Gryphon` conforming to `FlyingMonster`.
    - `Kraken` and `Merfolk` conforming to `WaterMonster`.

    Step 4: Create a Function to Handle Monsters
    - `printMonsterDetails(monsters: [Monster])` to print information for each monster, using polymorphism to call appropriate methods based on their type.

**Sample Output**
 
    Fire Drake roars fiercely, shaking the ground!
    Fire Drake spreads its 15.0-meter wings and takes to the sky!
    -----------------------
    Sky Hunter screeches with a piercing cry!
    Sky Hunter soars high with its majestic 12.0-meter wings!
    -----------------------
    Sea Terror bellows from the deep, causing waves to crash!
    Sea Terror glides through the water at 20 knots!
    -----------------------
    Coral Queen sings an enchanting melody that stirs the seas!
    Coral Queen swims gracefully at 10 knots!
    -----------------------
 */
protocol Monster {
    var name: String { get }
    
    func roar() -> String
} // Monster

protocol FlyingMonster: Monster {
    var wingSpan: Int { get }
    
    func fly() -> String
} // FlyingMonster
protocol WaterMonster: Monster {
    var swimSpeed: Int { get }
    
    func swim() -> String
} // FlyingMonster
class Dragon: FlyingMonster {
    
    var name: String
    var wingSpan: Int
    
    init(name: String, wingSpan: Int) {
        self.name = name
        self.wingSpan = wingSpan
    } // init
        func roar() -> String {
        return "roars fiercly, shaking the ground!"
    } // roar
    func fly() -> String {
        return "spreads its \(wingSpan)-meter wings and takes to the sky!"
    } // fly
} // Dragon
class Gryphon: FlyingMonster {
    
    var name: String
    var wingSpan: Int
    
    init(name: String, wingSpan: Int) {
        self.name = name
        self.wingSpan = wingSpan
    } // init
        func roar() -> String {
        return "screeches with a piercing cry!"
    } // roar
    func fly() -> String {
        return "soars high with its majestic \(wingSpan)-meter wings!"
    } // fly
} // Gryphon
class Kraken: WaterMonster {
    
    var name: String
    var swimSpeed: Int
    
    init(name: String, swimSpeed: Int) {
        self.name = name
        self.swimSpeed = swimSpeed
    } // init
        func roar() -> String {
        return "bellows from the deep, causing waves to crash!"
    } // roar
    func swim() -> String {
        return "glides through the water at \(swimSpeed) knots!"
    } // swim
} // Kraken
class Merfolk: WaterMonster {
    
    var name: String
    var swimSpeed: Int
    
    init(name: String, swimSpeed: Int) {
        self.name = name
        self.swimSpeed = swimSpeed
    } // init
        func roar() -> String {
        return "sings an enchanting melody that stirs the seas!"
    } // roar
    func swim() -> String {
        return "swims gracefully at \(swimSpeed) knots!"
    } // swim
} // Merfolk
func describeMonsters(monsters: [Monster]) {
    for munster in monsters {
        print("\(munster.name) \(munster.roar())")
        
        if let fly = munster as? FlyingMonster {
            print("\(fly.name) \(fly.fly())")
            print("--------------------------------")
        } // if let
        else if let wet = munster as? WaterMonster {
            print("\(wet.name) \(wet.swim())")
            print("--------------------------------")
        } // else if
    } // for
} // describeMonsters
let dragon: Dragon = Dragon(name: "Toothless", wingSpan: 15)
let gryphon: Gryphon = Gryphon(name: "Sonic", wingSpan: 12)
let kraken: Kraken = Kraken(name: "Ruby", swimSpeed: 20)
let merfolk: Merfolk = Merfolk(name: "Luna", swimSpeed: 10)

let monsters: [Monster] = [dragon, gryphon, kraken, merfolk]

describeMonsters(monsters: monsters)

